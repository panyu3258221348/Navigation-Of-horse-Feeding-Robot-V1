#include <rclcpp/rclcpp.hpp>
#include <sensor_msgs/msg/imu.hpp>
#include <geometry_msgs/msg/twist.hpp>
#include <tf2/LinearMath/Quaternion.h>
#include <tf2/LinearMath/Matrix3x3.h>
#include <Eigen/Dense>
#include <deque>
#include <algorithm>
#include <numeric>

class StraightController : public rclcpp::Node {
public:
  StraightController() : Node("imu_straight_controller") {
    // 参数声明
    declare_parameters();
    
    // 初始化滤波器窗口大小
    angle_filter_window_ = get_parameter("angle_filter_window").as_int();
    angular_vel_filter_window_ = get_parameter("angular_vel_filter_window").as_int();
    
    // 订阅和发布
    imu_sub_ = create_subscription<sensor_msgs::msg::Imu>(
      get_parameter("imu_topic").as_string(), 10,
      std::bind(&StraightController::imu_callback, this, std::placeholders::_1));
    
    cmd_pub_ = create_publisher<geometry_msgs::msg::Twist>(
      get_parameter("cmd_vel_topic").as_string(), 10);
    
    // PID参数初始化
    init_pid_controllers();
    
    // 参数变更回调
    param_handler_ = add_on_set_parameters_callback(
      std::bind(&StraightController::parameters_callback, this, std::placeholders::_1));

    RCLCPP_INFO(get_logger(), "Cascade PID controller initialized");
  }

private:
  void declare_parameters() {
    // 控制参数
    declare_parameter<double>("target_speed", 0.3);
    declare_parameter<double>("max_steering", 1.5);
    declare_parameter<double>("target_angle", 0.0);  // 目标角度（弧度）
    
    // 外环PID（角度环）
    declare_parameter<double>("angle_kp", 1.2);
    declare_parameter<double>("angle_ki", 0.01);
    declare_parameter<double>("angle_kd", 0.2);
    declare_parameter<double>("angle_integral_limit", 0.5);
    
    // 内环PID（角速度环）
    declare_parameter<double>("angular_vel_kp", 0.8);
    declare_parameter<double>("angular_vel_ki", 0.0);
    declare_parameter<double>("angular_vel_kd", 0.1);
    declare_parameter<double>("angular_vel_integral_limit", 1.0);
    
    // 滤波器参数
    declare_parameter<int>("angle_filter_window", 5);
    declare_parameter<int>("angular_vel_filter_window", 5);
    
    // 坐标系参数
    declare_parameter<std::vector<double>>("rotation_matrix", 
      {1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0});
    
    // 话题参数
    declare_parameter<std::string>("imu_topic", "/imu/data");
    declare_parameter<std::string>("cmd_vel_topic", "/cmd_vel");
  }

  void init_pid_controllers() {
    // 外环PID参数
    angle_pid_.kp = get_parameter("angle_kp").as_double();
    angle_pid_.ki = get_parameter("angle_ki").as_double();
    angle_pid_.kd = get_parameter("angle_kd").as_double();
    angle_pid_.integral_limit = get_parameter("angle_integral_limit").as_double();
    
    // 内环PID参数
    angular_vel_pid_.kp = get_parameter("angular_vel_kp").as_double();
    angular_vel_pid_.ki = get_parameter("angular_vel_ki").as_double();
    angular_vel_pid_.kd = get_parameter("angular_vel_kd").as_double();
    angular_vel_pid_.integral_limit = get_parameter("angular_vel_integral_limit").as_double();
  }

  rcl_interfaces::msg::SetParametersResult parameters_callback(
    const std::vector<rclcpp::Parameter> &parameters) 
  {
    auto result = rcl_interfaces::msg::SetParametersResult();
    result.successful = true;
    
    for (const auto &param : parameters) {
      // 动态更新PID参数
      if (param.get_name() == "angle_kp") angle_pid_.kp = param.as_double();
      if (param.get_name() == "angle_ki") angle_pid_.ki = param.as_double();
      if (param.get_name() == "angle_kd") angle_pid_.kd = param.as_double();
      if (param.get_name() == "angular_vel_kp") angular_vel_pid_.kp = param.as_double();
      if (param.get_name() == "angular_vel_ki") angular_vel_pid_.ki = param.as_double();
      if (param.get_name() == "angular_vel_kd") angular_vel_pid_.kd = param.as_double();
      
      // 动态更新滤波器窗口大小
      if (param.get_name() == "angle_filter_window") {
        angle_filter_window_ = param.as_int();
      }
      if (param.get_name() == "angular_vel_filter_window") {
        angular_vel_filter_window_ = param.as_int();
      }
    }
    return result;
  }

  void imu_callback(const sensor_msgs::msg::Imu::SharedPtr msg) {
    // 1. 坐标变换
    Eigen::Vector3d angular_vel_body = apply_coordinate_transform(msg);
    
    // 2. 角度计算
    double current_yaw = get_yaw_from_imu(msg);
    
    // 3. 角度滤波
    update_filter(angle_filter_, current_yaw, angle_filter_window_);
    double filtered_yaw = get_filtered_value(angle_filter_);
    
    RCLCPP_INFO(get_logger(), "yaw:%f",filtered_yaw);
    // 4. 外环PID计算（角度环）
    double target_angular_vel = angle_pid_controller(
      filtered_yaw, 
      get_parameter("target_angle").as_double());
    RCLCPP_INFO(get_logger(), "target_angular_vel:%f",target_angular_vel);
  
    // 5. 角速度滤波
    update_filter(angular_vel_filter_, angular_vel_body.z(), angular_vel_filter_window_);
    double filtered_angular_vel = get_filtered_value(angular_vel_filter_);
    RCLCPP_INFO(get_logger(), "filtered_angular_vel:%f",filtered_angular_vel);
    // 6. 内环PID计算（角速度环）
    double steering = angular_vel_pid_controller(
      filtered_angular_vel, 
      target_angular_vel);
    RCLCPP_INFO(get_logger(), "steering:%f",steering);
    // 7. 发布控制命令
    publish_control_command(steering);
  }

  Eigen::Vector3d apply_coordinate_transform(const sensor_msgs::msg::Imu::SharedPtr &msg) {
    Eigen::Vector3d angular_raw(
      msg->angular_velocity.x,
      msg->angular_velocity.y,
      msg->angular_velocity.z);
    
    auto rot_params = get_parameter("rotation_matrix").as_double_array();
    Eigen::Map<Eigen::Matrix3d> rotation_mat(rot_params.data());
    return rotation_mat.transpose() * angular_raw;
  }

  double get_yaw_from_imu(const sensor_msgs::msg::Imu::SharedPtr &msg) {
    tf2::Quaternion q(
      msg->orientation.x,
      msg->orientation.y,
      msg->orientation.z,
      msg->orientation.w);
    
    tf2::Matrix3x3 mat(q);
    double roll, pitch, yaw;
    mat.getRPY(roll, pitch, yaw);
    return yaw;
  }

  double angle_pid_controller(double current_angle, double target_angle) {
    static double last_error = 0.0;
    static double integral = 0.0;
    static rclcpp::Time last_time = now();
    
    double dt = (now() - last_time).seconds();
    double error = target_angle - current_angle;
    
    // 积分项
    integral += error * dt;
    integral = std::clamp(integral, 
                         -angle_pid_.integral_limit, 
                         angle_pid_.integral_limit);
    
    // 微分项
    double derivative = (error - last_error) / dt;
    
    // PID计算
    double output = angle_pid_.kp * error 
                   + angle_pid_.ki * integral 
                   + angle_pid_.kd * derivative;
    
    // 更新状态
    last_error = error;
    last_time = now();
    
    return output;
  }

  double angular_vel_pid_controller(double current_vel, double target_vel) {
    static double last_error = 0.0;
    static double integral = 0.0;
    static rclcpp::Time last_time = now();
    
    double dt = (now() - last_time).seconds();
    double error = target_vel - current_vel;
    
    // 积分项
    integral += error * dt;
    integral = std::clamp(integral, 
                         -angular_vel_pid_.integral_limit, 
                         angular_vel_pid_.integral_limit);
    
    // 微分项
    double derivative = (error - last_error) / dt;
    
    // PID计算
    double output = angular_vel_pid_.kp * error 
                   + angular_vel_pid_.ki * integral 
                   + angular_vel_pid_.kd * derivative;
    
    // 更新状态
    last_error = error;
    last_time = now();
    
    return std::clamp(output, 
                     -get_parameter("max_steering").as_double(),
                     get_parameter("max_steering").as_double());
  }

  void publish_control_command(double steering) {
    auto cmd_msg = std::make_unique<geometry_msgs::msg::Twist>();
    cmd_msg->linear.x = get_parameter("target_speed").as_double();
    cmd_msg->angular.z = steering;
    cmd_pub_->publish(std::move(cmd_msg));
    
    RCLCPP_DEBUG_THROTTLE(get_logger(), *get_clock(), 500,
      "Steering: %.3f rad/s, Speed: %.2f m/s", 
      steering, cmd_msg->linear.x);
  }

  // 滑动平均滤波器（修正版本）
  void update_filter(std::deque<double>& buffer, double new_value, size_t window_size) {
    buffer.push_back(new_value);
    if(buffer.size() > window_size) {
      buffer.pop_front();
    }
  }

  double get_filtered_value(const std::deque<double>& buffer) {
    if(buffer.empty()) return 0.0;
    return std::accumulate(buffer.begin(), buffer.end(), 0.0) / buffer.size();
  }

  struct PIDParams {
    double kp = 0.0;
    double ki = 0.0;
    double kd = 0.0;
    double integral_limit = 0.0;
  };

  // 成员变量
  rclcpp::Subscription<sensor_msgs::msg::Imu>::SharedPtr imu_sub_;
  rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr cmd_pub_;
  OnSetParametersCallbackHandle::SharedPtr param_handler_;
  
  PIDParams angle_pid_;          // 外环角度环PID
  PIDParams angular_vel_pid_;    // 内环角速度环PID
  
  std::deque<double> angle_filter_;          // 角度滤波器
  std::deque<double> angular_vel_filter_;    // 角速度滤波器
  
  size_t angle_filter_window_;      // 角度滤波器窗口大小
  size_t angular_vel_filter_window_; // 角速度滤波器窗口大小
};

int main(int argc, char** argv) {
  rclcpp::init(argc, argv);
  auto node = std::make_shared<StraightController>();
  rclcpp::spin(node);
  rclcpp::shutdown();
  return 0;
}